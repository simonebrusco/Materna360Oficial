export const DAILY_MESSAGES: readonly string[] = [
  'Respire fundo — você está fazendo o seu melhor hoje.',
  'O amor que você oferece é tudo o que seu filho precisa agora.',
  'Você não precisa ser perfeita, apenas presente e verdadeira.',
  'Pequenos gestos de carinho criam memórias gigantes.',
  'Cuidar de você também é cuidar da sua família.',
  'Confie no seu instinto: você conhece sua família melhor do que ninguém.',
  'Se o dia estiver corrido, abrace devagar e sinta a calma chegar.',
  'Você é o porto seguro nos momentos de caos.',
  'Cada sorriso deles é um lembrete de que você está no caminho certo.',
  'Quando a dúvida aparecer, escolha a conexão — ela nunca falha.',
  'Permita-se pausar: descanso também é produtividade.',
  'Celebre as pequenas conquistas do dia e tenha orgulho do seu caminho.',
]
